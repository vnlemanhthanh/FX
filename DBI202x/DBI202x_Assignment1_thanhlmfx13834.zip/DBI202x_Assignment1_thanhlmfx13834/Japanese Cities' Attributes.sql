SELECT *
  FROM CITY
  WHERE CountryCode = 'JPN'