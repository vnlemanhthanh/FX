SELECT *
  FROM CITY
  WHERE Population > 100000 AND CountryCode = 'USA'