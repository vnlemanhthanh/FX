SELECT NAME
  FROM CITY
  WHERE Population > 120000 AND CountryCode = 'USA'