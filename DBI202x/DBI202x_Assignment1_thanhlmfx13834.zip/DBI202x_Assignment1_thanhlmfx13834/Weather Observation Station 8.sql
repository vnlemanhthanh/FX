SELECT DISTINCT CITY
    FROM STATION
    WHERE CITY like '[aeiou]%[aeiou]'