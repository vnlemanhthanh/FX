SELECT MAX(Population) - Min(Population)
FROM CITY