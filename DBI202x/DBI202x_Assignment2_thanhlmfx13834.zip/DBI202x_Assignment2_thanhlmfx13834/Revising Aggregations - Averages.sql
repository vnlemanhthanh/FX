SELECT AVG(Population)
FROM CITY 
WHERE District = 'California'