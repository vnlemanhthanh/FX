SELECT SUM(Population)
FROM CITY 
WHERE District = 'California'